#include<stdio.h>
#define max 4
int top=-1;
int stack_arr[max];
void push(int data){
	if(top==max-1){
		printf("stack overflow");
		return ;
	}
	top++;
	stack_arr[top]=data;
}

void pop(){
	if(top==-1){
		printf("stack underflow");
	}
	//stack_arr[top]=0;
	top--;
	
}
int peek(){
	return stack_arr[top];
}

bool isFull(){
	if(top==max-1) return true;
	else return false;

}
bool isEmpty(){
	if(isFull) return false;
	else return true;
}

int main(){
	push(4);
	push(5);
	push(7);
	push(6);
	pop();
	
	for(int i=0;i<=top;i++){
	printf("%d ",stack_arr[i]);
	}
	printf("%d",peek());
}
