#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
		}
		back->link=temp;
		back=temp;
		
		
	}
	void pop(){
		if(front==NULL){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		front=front->link;
	}
	int peek(){
		return front->data;
	}
	
};
int main(){



	queue q;
	
 
	q.push(1);
	q.push(2);
	q.push(3);
	q.push(4);
	for(int i=0;i<3;i++){
	cout<<q.peek()<<endl;
	q.pop();
	}













}
