#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
} *top=NULL;

void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
	
}

void pop(){
	top=top->link;
	
}

void check(char s[]){
	int i=0;
	while(s[i]){
		
	if(s[i]=='('){push(s[i]);}
	
	else {
		if(top==NULL){
		printf("unbalaced");return ;
			
		}
		else {pop();}
	}
	i++;
	
	}
	if(top==NULL) printf("balanced");
	else printf("unbalaced");
	
}

int main(){
	char s[10];
	scanf("%s",s);
	check(s);
}
