#include<iostream>
#include<math.h>

using namespace std;
struct node{
	int data;
	struct node* link;
} *top=NULL;
void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
}
int  pop(){
int val=top->data;
	top=top->link;
	return val;
}
void check(char s[]){
	int i=0;
	while(s[i]){
		
		if(s[i]=='/'||s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='^') {
			int a=pop();
			//printf("%d",a);
			int b=pop();
			//printf("%d",b);
			int c;
			if(s[i]=='*'){
				c=a*b;
			}
			else if(s[i]=='/'){
				c=b/a;
			}
			else if(s[i]=='^'){
				c=pow(b,a);
			}
			else if(s[i]=='+'){
				c=b+a;
			}
			else {
				c=b-a;
			}
			//printf("%d ",c);
			push(c);
		}
		else { push(s[i]-'0');}
		
		i++;
	}
	int d=pop();
	printf("%d ",d);
}
int main(){
	char s[34];
	scanf("%s",s);
	check(s);
}
