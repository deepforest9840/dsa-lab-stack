#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
} *top=NULL;

void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
	
}
int pop(){
	int a=top->data;
	top=top->link;
	return a;
}

int peek(){
	return top->data;
}
void print(){
	struct node* temp=top;
	while(temp!=NULL){
		printf("%c ",temp->data);
		temp=temp->link;
	}
	
}
int isEmpty(){
	if(top==NULL){
		return 1;
		
	}
	else return 0;
}
void check(char s[]){
	int i=0;
	
	while(s[i]!='x'){
		push(s[i]);
		i++;
	}
	i++;
	while(s[i]){
		if(isEmpty()||s[i]!=(char)pop()){
		printf("Not a Palindrome \n");
		return ;
		}
		i++;
	}
	printf("palindrome");
}

int main(){
	char s[10]="abaxaba";
	check(s);
}
