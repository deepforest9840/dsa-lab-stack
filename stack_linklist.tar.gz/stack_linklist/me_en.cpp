#include<iostream>
using namespace std;
struct node{
	char* s;
	struct node* link;
}*top=NULL;
void push(char s[]){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->s=s;
	temp->link=top;
	top=temp;
}
void print(){
	struct node* temp=top;
	while(top!=NULL){
		printf("%s\n",top->s);
		top=top->link;
		
	}
}
int main(){
	char s1[]="ami";
	char s2[]="tmi";
	push(s1);
	push(s2);
	print();
}
