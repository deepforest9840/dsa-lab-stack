#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct node* push(int d,struct node* top){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=d;
		temp->link=top;
		top=temp;
	return top;
}

struct node* pop(struct node* top){
	struct node* temp;

	top=top->link;
	temp=top;
	return temp;
}
struct node* add_ar_last(int data,struct node* top){
	struct node* temp=top;
	while(temp->link!=NULL){
		temp=temp->link;
	}
	temp->data=data;
	temp->link=NULL;
return top;
}
void  add_at_last(int data1,struct node *head){
struct node *temp=(struct node *)malloc(sizeof(struct node));
	temp->data=data1;
	if(head->data==0){
		head->data=data1;
		return ;
		
	}
	
	while(head->link!=NULL){

		//printf("%d\n",head->data);
			head=head->link;
	}
	head->link=temp;//head=head->link;
	//printf("%d",head->data);
	//return head;
}
void print(struct node* top){
	struct node* temp=top;
	if(top==NULL) {
		printf("stack underflow\n");
		exit(1);
	}
	while(temp!=NULL){
		printf("%d ",temp->data);
		temp=temp->link;
	}
}


int main(){
	struct node* top=NULL;
	struct node* top1=NULL;
	struct node* top2=NULL;
	top=push(3,top);
	top=push(2,top);
	top=push(1,top);
	
	print(top);
		
		struct node* temp;
		temp=pop(top);
		top1=push(temp->data,top1);
		
	printf("\n");
	
	print(top1);
	//print(top);
}
