#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
} *top=NULL;
void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
	
}
int pop(){
	int val=top->data;
	top=top->link;
	return val;
}


void check(char s[]){
	int i=0;
	while(s[i]){
		
		
		if(s[i]>='0'&&s[i]<='9') {printf("%c ",s[i]);}
		if(s[i]=='('){
			push(s[i]);
		}
		if(s[i]==')') {
			while(top->data!='('){
				printf("%c ",pop());
			}
			pop();
		}
		if( s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'||s[i]=='^'){
			if(top!=NULL){
			if( (s[i]=='+'||s[i]=='-')&&(top->data=='^'||(top->data=='*')||top->data=='/'||top->data=='+'||top->data=='-')){
				
	
				while(1){
				if(top==NULL){break;}
				else if(top->data=='+'||top->data=='-'){
					break;}
					printf("%c ",pop());
				}
				if(top!=NULL){
				if(top->data=='+'||top->data=='-'){printf("%c ",pop());}
				}
				push(s[i]);
			}
		else if((s[i]=='*'||s[i]=='/')&&(top->data=='*'||top->data=='/'||top->data=='^')){
				while(1){
				
					if(top==NULL){break;}
					else if(top->data=='+'||top->data=='-'){
				break;
					}
						printf("%c ",pop());
				}
				push(s[i]);
			}
		
			
		
			
			else push(s[i]);
			}
			else push(s[i]);
		}
		
		i++;
	}
	while(top!=NULL){
		printf("%c ",top->data);
		top=top->link;
	}
	
	
}


int main(){
	char s[20];
	scanf("%s",s);
	check(s);
}































